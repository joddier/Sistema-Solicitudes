<footer class="main-footer">
	
	<strong>Copyright &copy; 2022.</strong>

	Todos los derechos reservados.


</footer>